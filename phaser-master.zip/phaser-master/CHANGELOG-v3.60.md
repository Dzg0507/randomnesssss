[This file has now moved](changelog/3.60/CHANGELOG-v3.60.md).
